#ifndef __SIG_HANDLER_H__
#define __SIG_HANDLER_H__

#include <stdbool.h>

extern bool running;

int set_termhandler(void);

#endif
