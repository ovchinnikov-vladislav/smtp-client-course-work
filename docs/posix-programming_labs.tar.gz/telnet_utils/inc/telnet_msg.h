#ifndef __TELNET_MSG_H__
#define __TELNET_MSG_H__

#define TELNET_SUFFIX "\r\n"
#define TELNET_SUFFIX_LEN ((int) sizeof(TELNET_SUFFIX) - 1)

#endif
