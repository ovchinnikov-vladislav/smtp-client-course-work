#ifndef __DUMB_SERVER_H__
#define __DUMB_SERVER_H__

#include "db_virtual.h"

//
void run_server(int binded_socket, struct vdb *db);

#endif
