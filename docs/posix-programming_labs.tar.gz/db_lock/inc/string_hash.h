#ifndef __STRING_HASH_H__
#define __STRING_HASH_H__

// Returns some string hash.
int string_hash(char *string);

#endif
